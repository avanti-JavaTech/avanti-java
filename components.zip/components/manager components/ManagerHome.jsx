import React, { Component } from "react";

class ManagerHome extends Component{
    constructor(props) {
        super(props);
    }

    render() {
        return(
            <div>
                <p>Manager Home</p>
            </div>
        );
    }
}

export default ManagerHome;