import React, { Component } from "react";

class HeadManagerHome extends Component{
    constructor(props) {
        super(props);
    }

    render() {
        return(
            <div>
                <p>Head Manager Home</p>
            </div>
        );
    }
}

export default HeadManagerHome;