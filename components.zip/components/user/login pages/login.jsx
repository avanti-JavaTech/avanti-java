import React, { Component } from "react";

import OuterNavbar from "../../navbar/OuterNavbar";
import HeadManagerLogin from "./HeadManagerLogin";
import CustomerLogin from "./CustomerLogin";
import DeliveryBoyLogin from './DeliveryBoyLogin';
import ManagerLogin from './ManagerLogin';

class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            form: <CustomerLogin />
        }

        this.changeFormState = this.changeFormState.bind(this);
    }

    changeFormState(formState) {
        this.setState({form: formState})
    }

    render() {
        return (
            <div style={{
                backgroundColor: '#D3D3D3	',
              }}>
                <OuterNavbar />

                <div>
                    <ul className="nav justify-content-end">
                        <li className="nav-link" class="btn btn-outline-primary" style={{cursor:"pointer"}} onClick={() => this.changeFormState(<HeadManagerLogin/>)}>
                            Head Manager Login
                        </li>&nbsp;  &nbsp;  

                        <li className="nav-link" class="btn btn-outline-primary" style={{cursor:"pointer"}} onClick={() => this.changeFormState(<ManagerLogin/>)}>
                            Manager Login
                        </li>&nbsp;  &nbsp;  

                        <li className="nav-link" class="btn btn-outline-primary" style={{cursor:"pointer"}} onClick={() => this.changeFormState(<DeliveryBoyLogin/>)}>
                            Delivery Boy Login
                        </li>&nbsp;  &nbsp;  

                        <li className="nav-link" class="btn btn-outline-primary" style={{cursor:"pointer"}} onClick={() => this.changeFormState(<CustomerLogin/>)}>
                            Customer Login
                        </li>&nbsp;  &nbsp;  
                    </ul>
                </div>

                {this.state.form}
            </div>
        )
    }
}
export default Login;